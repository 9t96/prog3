<?php
include_once("../Clases/usuarios.php");


    usuarios::Listar();


?>