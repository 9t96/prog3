<?php
require_once("../Clases/container.php");

Container::TraerTabla();

?>